class pessoa:
    def __init__(self,  nome=None, email=None):
        self.nome = nome
        self.email = email
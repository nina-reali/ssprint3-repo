CPFS_CNPJS_BLOQUEADOS_ORDEM_JUDICIAL = ["414.438.993-64", "563.770.497-06", "333.289.702-07", "363.733.588-36", "293.688.831-06"]
CNPJS_BLOQUEADOS_SUSPEITA_ORIGEM_DINHEIRO = ["12.079.352/0246-90"]

SUSPEITA_FRAUDE_IDENTIDADE_CORRENTISTA = "Suspeita de Fraude na Identidade do Correntista"
ORDEM_JUDICIAL = "Ordem Judicial",
SUSPEITA_LAVAGEM_DINHEIRO = "Suspeita de Lavagem de Dinheiro"
SUSPEITA_ORIGEM_DINHEIRO = "Comprovação de Origem do Dinheiro"
ATIVIDADE_ILEGAL = "Atividade Ilegal"
SONEGACAO_IMPOSTOS = "Sonegação de Impostos"
SUSPEITA_DEVICE_DIFERENTE = "Device Padrão Adulterado"
SUSPEITA_LOCAL_TRANSACAO = "Local da transação diferente do padrão"
CONTAS_BLOQUEADAS_23 = ["928.723.059-55", "166.819.546-18", "077.601.304-14", "057.404.502-33", "160.829.740-34","44.091.697/9621-41"]
BLOQUEADAS_23 = "Contas bloqueadas excedeu o limite de tempo previsto para uma resposta do usuário"